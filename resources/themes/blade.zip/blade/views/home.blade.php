{{-- resources/themes/modern/views/home.blade.php --}}
@extends('layouts.app')

@section('content')
    <div class="text-center py-20">
        <h1 class="text-4xl font-bold">Modern Theme Homepage</h1>
    </div>
@endsection